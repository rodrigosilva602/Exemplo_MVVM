﻿using OQueEMVVM.Commands;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace OQueEMVVM.ViewModel
{
    public class ConfiguracoesViewModel : INotifyPropertyChanged
    {
        #region Atributos
        private Model.ConfiguracoesPerfil configuracao;

        private bool ativo;
        private string nome;
        private string mensagem;
        private string resultado;
        #endregion

        #region Propriedades
        public bool Ativo
        {
            get { return ativo; }
            set
            {
                ativo = value;
                NotificarPropriedadeAlterada();
            }
        }

        public string Nome
        {
            get { return nome; }
            set
            {
                nome = value;
                NotificarPropriedadeAlterada();
                Salvar.RaiseCanExecuteChanged();
            }
        }

        public string Mensagem
        {
            get { return mensagem; }
            set
            {
                mensagem = value;
                NotificarPropriedadeAlterada();
                Salvar.RaiseCanExecuteChanged();
            }
        }

        public string Resultado
        {
            get { return resultado; }
            private set
            {
                resultado = value;
                NotificarPropriedadeAlterada();
            }
        }

        public RelayCommand Salvar { get; private set; }
        #endregion

        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        private void NotificarPropriedadeAlterada([CallerMemberName] string propriedade = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propriedade));
        }
        #endregion

        #region Métodos
        public ConfiguracoesViewModel()
        {
            configuracao = new Model.ConfiguracoesPerfil();

            Salvar = new RelayCommand(
                () => {
                    configuracao.Salvar(ativo, nome, mensagem);
                    Resultado = "Status alterado com sucesso.";
                },
                () => {
                    Resultado = "";

                    if (String.IsNullOrWhiteSpace(nome))
                    {
                        Resultado = "O nome não pode ficar vazio.";
                        return false;
                    }
                    else if (String.IsNullOrWhiteSpace(mensagem))
                    {
                        Resultado = "A mensagem não pode ficar vazia.";
                        return false;
                    }
                    else return true;
                }
            );
        }
        #endregion
    }
}
