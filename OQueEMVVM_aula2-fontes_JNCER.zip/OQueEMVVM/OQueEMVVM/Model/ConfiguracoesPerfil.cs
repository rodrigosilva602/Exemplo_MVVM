﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OQueEMVVM.Model
{
    public class ConfiguracoesPerfil
    {
        public void Salvar(bool ativo, string nome, string mensagem)
        {
            //Gravar alterações
        }
    }
}
